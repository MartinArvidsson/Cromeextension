﻿function initialize() {
    console.log("Entered")
    chrome.webRequest.onBeforeSendHeaders.addListener(_onChromeWebRequestBeforeSendHeaders, {
        urls: ["<all_urls>"]
    }, ['blocking', 'requestHeaders']);
}
function _onChromeWebRequestBeforeSendHeaders(info) {
    var refererRequestHeader = _getHeader(info.requestHeaders, 'Referer');
    var referer = 'https://www.youtube.com/';

    if (isUndefined(refererRequestHeader)) {
        info.requestHeaders.push({
            name: 'Referer',
            value: referer
        });
    }
}
function _getHeader(requestHeaders, headerName) {
    var refererRequestHeader = _.find(requestHeaders, function (requestHeader) {
        return requestHeader.name === headerName;
    });
    return refererRequestHeader;
}
